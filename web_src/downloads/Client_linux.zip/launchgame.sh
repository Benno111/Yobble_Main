echo "🎮 Launching http://photography-cage.gl.at.ply.gg:52426/"
./Yobble --no-sandbox
